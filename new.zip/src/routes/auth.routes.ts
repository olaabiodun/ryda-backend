import { Router } from 'express';
import authController from '../controllers/auth.controller';
import authMiddleware from '../middlewares/auth.middleware';

const router = Router();

router.post('/request-otp', authController.requestOtp);
router.post('/register', authController.register);
router.post('/login', authController.verifyOtp);
router.post('/topup', authMiddleware, authController.topUp);
router.post('/send', authMiddleware, authController.sendMoney);
router.post('/withdraw', authMiddleware, authController.withdraw);
router.get('/profile', authMiddleware, authController.getProfile);
router.get('/transactions', authMiddleware, authController.getTransactions);
router.post('/google', authController.googleAuth);
router.post('/request-email-change', authMiddleware, authController.requestEmailChangeOtp);
router.patch('/profile', authMiddleware, authController.updateProfile);
router.post('/push-token', authMiddleware, authController.savePushToken);

// Partner auth routes
router.post('/partner/signup', authController.registerPartner);
router.post('/partner/login', authController.loginPartner);
router.get('/partner/check/:code', authController.checkPartnerCode);

export default router;
